import 'package:flutter/material.dart';

class VisualDesignScreen extends StatelessWidget {
  const VisualDesignScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox( // Canvas Area
        width: double.infinity,
        height: double.infinity,
        child: Stack(
          children: [
            Positioned(
              left: 171,
              top: 163,
              width: 48,
              height: 48,
              child: Icon(Icons.star, color: Color(4278190080), size: 24),
            ),
            Positioned(
              left: 166,
              top: 248,
              width: 100,
              height: 100,
              child: Image.network('https://picsum.photos/200', fit: BoxFit.cover),
            ),
          ],
        ),
      ),
    );
  }
}
