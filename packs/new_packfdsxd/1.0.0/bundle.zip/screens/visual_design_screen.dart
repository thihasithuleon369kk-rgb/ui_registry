import 'package:flutter/material.dart';

class VisualDesignScreen extends StatelessWidget {
  const VisualDesignScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox( // Canvas Area
        width: double.infinity,
        height: double.infinity,
        child: Stack(
          children: [
            Positioned(
              left: 13,
              top: 24,
              width: 361,
              height: 308,
              child: Column(children: const [Text('Column')]),
            ),
            Positioned(
              left: 52,
              top: 61,
              width: 181,
              height: 60,
              child: Container(
          padding: const EdgeInsets.all(0),
          decoration: BoxDecoration(
            color: Color(4294967295),
            borderRadius: BorderRadius.circular(8),
            
            
          ),
          child: const SizedBox.expand(),
        ),
            ),
            Positioned(
              left: 58,
              top: 130,
              width: 175,
              height: 100,
              child: Container(
          padding: const EdgeInsets.all(0),
          decoration: BoxDecoration(
            color: Color(4294967295),
            borderRadius: BorderRadius.circular(8),
            
            
          ),
          child: const SizedBox.expand(),
        ),
            ),
          ],
        ),
      ),
    );
  }
}
