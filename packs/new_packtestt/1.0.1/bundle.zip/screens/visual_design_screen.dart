import 'package:flutter/material.dart';

class VisualDesignScreen extends StatelessWidget {
  const VisualDesignScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox( // Canvas Area
        width: double.infinity,
        height: double.infinity,
        child: Stack(
          children: [
            Positioned(
              left: 0,
              top: 32,
              width: 245,
              height: 100,
              child: Container(
          padding: const EdgeInsets.all(0),
          decoration: BoxDecoration(
            color: Color(4294967295),
            borderRadius: BorderRadius.circular(8),
            
            
          ),
          child: const SizedBox.expand(),
        ),
            ),
            Positioned(
              left: 150,
              top: 282,
              width: 403,
              height: 200,
              child: Container() /* Custom Widget Placeholder */,
            ),
          ],
        ),
      ),
    );
  }
}
