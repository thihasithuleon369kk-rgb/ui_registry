import 'package:flutter/material.dart';

class VisualDesignScreen extends StatelessWidget {
  const VisualDesignScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox( // Canvas Area
        width: double.infinity,
        height: double.infinity,
        child: Stack(
          children: [
          ],
        ),
      ),
    );
  }
}
