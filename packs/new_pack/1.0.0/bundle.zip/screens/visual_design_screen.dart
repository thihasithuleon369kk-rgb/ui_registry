import 'package:flutter/material.dart';

class VisualDesignScreen extends StatelessWidget {
  const VisualDesignScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox( // Canvas Area
        width: double.infinity,
        height: double.infinity,
        child: Stack(
          children: [
            Positioned(
              left: 145,
              top: 189,
              width: 100,
              height: 100,
              child: Container(
          padding: const EdgeInsets.all(0),
          decoration: BoxDecoration(
            color: Color(4294967295),
            borderRadius: BorderRadius.circular(8),
            
            
          ),
          child: const SizedBox.expand(),
        ),
            ),
          ],
        ),
      ),
    );
  }
}
