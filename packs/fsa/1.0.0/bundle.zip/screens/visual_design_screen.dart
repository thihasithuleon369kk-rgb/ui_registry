import 'package:flutter/material.dart';

class VisualDesignScreen extends StatelessWidget {
  const VisualDesignScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox( // Canvas Area
        width: double.infinity,
        height: double.infinity,
        child: Stack(
          children: [
            Positioned(
              left: 187,
              top: 271,
              width: 100,
              height: 100,
              child: Card(child: Padding(padding: EdgeInsets.all(16.0), child: Text('Card'))),
            ),
          ],
        ),
      ),
    );
  }
}
